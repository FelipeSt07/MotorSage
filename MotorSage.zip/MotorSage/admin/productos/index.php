<?php

include ("../config/conexion.php");
include ("../config/config.php");
require '../header.php';

if (!isset($_SESSION['user_type'])) {
    header('Location: ../index.php');
    exit;
}

if ($_SESSION['user_type'] != 'admin') {
    header('Location: ../../index.php');
    exit;
}
$conexion = conectar();


?>
<main>
    <div class="container-fluid px-4">
        <h2 class="mt-2">Productos</h2>

        <a class="btn btn-primary" href="nuevo.php">Agregar</a>

        <table class="table table-hover my-4">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>

            <tbody>

            </tbody>
        </table>
    </div>
</main>

<?php  require '../footer.php';  ?>