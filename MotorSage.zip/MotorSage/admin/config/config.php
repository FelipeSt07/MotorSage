<?php

session_start();    

define('ADMIN_URL', 'http://localhost/MotorSage1/MotorSage/admin/');